const openBtn = document.getElementById("openSurprise");
const closeBtn = document.getElementById("closeSurprise");
const nestedPage = document.getElementById("nestedPage");
const bgMusic = document.getElementById("bgMusic");

openBtn.addEventListener("click", () => {
  nestedPage.classList.add("active");

  bgMusic.currentTime = 0;
  bgMusic.volume = 0;
  bgMusic.muted = false;

  bgMusic.play();

  let vol = 0;
  const fade = setInterval(() => {
    if (vol < 0.6) {
      vol += 0.05;
      bgMusic.volume = vol;
    } else {
      clearInterval(fade);
    }
  }, 200);
});

closeBtn.addEventListener("click", () => {
  nestedPage.classList.remove("active");
  bgMusic.pause();
  bgMusic.currentTime = 0;
});
